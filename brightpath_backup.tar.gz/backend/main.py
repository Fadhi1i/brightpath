# main.py — BrightPath (Supabase-aligned)
import os
from datetime import datetime
from typing import Any, Dict, List, Optional
from openai import OpenAI
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# load .env
from dotenv import load_dotenv
load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
# supabase client
from supabase import create_client, Client

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = (
    os.getenv("SUPABASE_SERVICE_ROLE")
    or os.getenv("SUPABASE_ANON_KEY")
    or os.getenv("SUPABASE_KEY")
)
if not SUPABASE_URL or not SUPABASE_KEY:
    raise RuntimeError("Missing SUPABASE_URL and key.")

sb: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

# password utils
import bcrypt
def hash_pw(p: str) -> str:
    return bcrypt.hashpw(p.encode(), bcrypt.gensalt()).decode()
def check_pw(p: str, hashed_or_plain: str) -> bool:
    try:
        return bcrypt.checkpw(p.encode(), hashed_or_plain.encode())
    except Exception:
        return p == hashed_or_plain  # fallback for legacy plaintext

app = FastAPI(title="BrightPath API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("ALLOWED_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─────────── Schemas (requests) ───────────
class LoginIn(BaseModel):
    email: str
    password: str

class UserOut(BaseModel):
    id: int
    name: str
    email: str
    role: str

class SubjectIn(BaseModel):
    name: str

class StudentIn(BaseModel):
    name: str
    gender: Optional[str] = None
    date_of_birth: Optional[str] = None  # yyyy-mm-dd
    grade: str

class StudentUpdateIn(StudentIn):
    pass

class AnnouncementIn(BaseModel):
    message: str
    posted_by: Optional[str] = "Admin"

class ParentSignupIn(BaseModel):
    name: str
    email: str
    password: str
    phone: Optional[str] = None
    admission_no: str

class TeacherSignupIn(BaseModel):
    name: str
    email: str
    password: str
    department: Optional[str] = ""
    subjects: Optional[List[int]] = []  # subject ids
    grades: Optional[List[str]] = []    # grade labels

class AdminSignupIn(BaseModel):
    name: str
    email: str
    password: str

class SummarizeIn(BaseModel):
    text: str = Field(..., min_length=1)

# ─────────── Helpers ───────────
def http_400(msg: str): raise HTTPException(status_code=400, detail=msg)
def http_401(): raise HTTPException(status_code=401, detail="Invalid email or password.")
def http_404(msg: str): raise HTTPException(status_code=404, detail=msg)

# ─────────── Health ───────────
@app.get("/health")
def health():
    return {"status": "ok", "time": datetime.utcnow().isoformat()}

# ─────────── Auth & Signup ───────────
def _get_user_from_users(email: str) -> Optional[Dict[str, Any]]:
    try:
        r = sb.table("users").select("*").eq("email", email).limit(1).execute()
        return r.data[0] if r.data else None
    except Exception:
        return None

def _get_parent_by_email(email: str) -> Optional[Dict[str, Any]]:
    try:
        r = sb.table("parents").select("*").eq("email", email).limit(1).execute()
        return r.data[0] if r.data else None
    except Exception:
        return None

@app.post("/login", response_model=UserOut)
def login(body: LoginIn):
    # 1) Try unified users (admin/teacher)
    u = _get_user_from_users(body.email)
    if u:
        pw = u.get("password_hash") or ""
        if not pw or not check_pw(body.password, pw):
            http_401()
        return UserOut(id=u["id"], name=u.get("name",""), email=u["email"], role=u["role"])

    # 2) Try parents table
    p = _get_parent_by_email(body.email)
    if p:
        pw = p.get("password_hash") or ""
        if not pw or not check_pw(body.password, pw):
            http_401()
        # For frontend role routing
        return UserOut(id=p["id"], name=p.get("name",""), email=p["email"], role="parent")

    http_401()

@app.post("/signup-parent")
@app.post("/parent/signup")
def signup_parent(body: ParentSignupIn):
    # parents(email unique)
    ex = sb.table("parents").select("id").eq("email", body.email).limit(1).execute()
    if ex.data: http_400("Email already registered.")
    row = {
        "name": body.name,
        "email": body.email,
        "phone": body.phone,
        "password_hash": hash_pw(body.password),
    }
    created = sb.table("parents").insert(row).execute()
    if not created.data: http_400("Failed to create parent.")
    parent_id = created.data[0]["id"]

    # Link to student via admission_no if present (optional; ignore if not found)
    try:
        s = sb.table("students").select("id").eq("reg_no", body.admission_no).limit(1).execute()
        if s.data:
            sb.table("parent_child").upsert({
                "parent_id": parent_id,
                "student_id": s.data[0]["id"]
            }, on_conflict="parent_id,student_id").execute()
    except Exception:
        pass

    return {"success": True, "message": "Parent account created successfully!"}

@app.post("/signup-teacher")
def signup_teacher(body: TeacherSignupIn):
    # Create in users (authoritative for auth)
    ex = sb.table("users").select("id").eq("email", body.email).limit(1).execute()
    if ex.data: http_400("Email already registered.")
    u = sb.table("users").insert({
        "name": body.name,
        "email": body.email,
        "password_hash": hash_pw(body.password),
        "role": "teacher",
    }).execute()
    if not u.data: http_400("Failed to create user.")
    user_id = u.data[0]["id"]

    # Create in teachers (profile)
    t = sb.table("teachers").insert({
        "name": body.name,
        "email": body.email,
        # store hash to keep parity with users table (schema column is 'password')
        "password": hash_pw(body.password),
        "department": body.department or "",
        "subjects": body.subjects or [],
        "grades": body.grades or [],
        "created_at": datetime.utcnow().isoformat(),
    }).execute()
    if not t.data: http_400("Failed to create teacher profile.")
    teacher_id = t.data[0]["id"]

    # Map teacher_subjects rows
    for sid in (body.subjects or []):
        sb.table("teacher_subjects").upsert(
            {"teacher_id": teacher_id, "subject_id": sid},
            on_conflict="teacher_id,subject_id"
        ).execute()

    return {"success": True, "message": "Teacher account created successfully!", "user_id": user_id, "teacher_id": teacher_id}

@app.post("/add-teacher")
def add_teacher_minimal(body: AdminSignupIn):
    # minimal path used by main.js: only users+teachers basic
    ex = sb.table("users").select("id").eq("email", body.email).limit(1).execute()
    if ex.data: http_400("Email already registered.")
    user = sb.table("users").insert({
        "name": body.name, "email": body.email, "password_hash": hash_pw(body.password), "role": "teacher"
    }).execute()
    teacher = sb.table("teachers").insert({
        "name": body.name, "email": body.email, "password": hash_pw(body.password),
        "department": "", "subjects": [], "grades": [], "created_at": datetime.utcnow().isoformat()
    }).execute()
    return {"success": True, "message": "Teacher created."}

@app.post("/add-admin")
def add_admin(body: AdminSignupIn):
    ex = sb.table("users").select("id").eq("email", body.email).limit(1).execute()
    if ex.data: http_400("Email already registered.")
    sb.table("users").insert({
        "name": body.name, "email": body.email, "password_hash": hash_pw(body.password), "role": "admin"
    }).execute()
    return {"success": True, "message": "Admin created."}

# ─────────── Subjects ───────────
@app.get("/get-subjects")
def get_subjects():
    res = sb.table("subjects").select("id,name").order("name").execute()
    return {"success": True, "subjects": res.data or []}

@app.post("/add-subject")
def add_subject(body: SubjectIn):
    ex = sb.table("subjects").select("id").eq("name", body.name).limit(1).execute()
    if ex.data: http_400("Subject already exists.")
    sb.table("subjects").insert({"name": body.name}).execute()
    return {"success": True, "message": f"Subject '{body.name}' added."}

# ─────────── Students ───────────
@app.post("/add-student")
def add_student(body: StudentIn):
    row = {
        "name": body.name,
        "gender": body.gender,
        "date_of_birth": body.date_of_birth,
        "grade": body.grade,
        # reg_no is generated by trigger generate_reg_no(); if missing in your DB, fallback generation below
    }
    try:
        sb.table("students").insert(row).execute()
        return {"success": True, "message": f"Student '{body.name}' added"}
    except Exception as e:
        # Fallback: generate reg_no locally if trigger not present
        ts = datetime.utcnow().strftime("%y%m%d%H%M%S")
        row["reg_no"] = f"{body.grade.replace(' ', '')}-{ts}"
        sb.table("students").insert(row).execute()
        return {"success": True, "message": f"Student '{body.name}' added (local reg_no)"}

@app.get("/get-students")
def get_students():
    res = sb.table("students").select("*").order("id").execute()
    students = res.data or []
    # parent_name via parent_child -> parents
    s_ids = [s["id"] for s in students]
    if s_ids:
        links = sb.table("parent_child").select("parent_id,student_id").in_("student_id", s_ids).execute().data or []
        p_ids = list({x["parent_id"] for x in links})
        parents = sb.table("parents").select("id,name").in_("id", p_ids or [-1]).execute().data or []
        pmap = {p["id"]: p["name"] for p in parents}
        cmap = {x["student_id"]: x["parent_id"] for x in links}
        for s in students:
            s["parent_name"] = pmap.get(cmap.get(s["id"]), None)
    return {"students": students}

@app.put("/update-student/{student_id}")
def update_student(student_id: int, body: StudentUpdateIn):
    sb.table("students").update({
        "name": body.name,
        "gender": body.gender,
        "date_of_birth": body.date_of_birth,
        "grade": body.grade,
    }).eq("id", student_id).execute()
    return {"success": True, "message": "Student updated successfully"}

@app.delete("/delete-student/{student_id}")
def delete_student(student_id: int):
    sb.table("students").delete().eq("id", student_id).execute()
    return {"success": True, "message": "Student deleted successfully"}

# ─────────── Teachers & Parents lists ───────────
@app.get("/get-teachers")
def get_teachers():
    t = sb.table("teachers").select("*").order("id").execute().data or []
    # join teacher_subjects -> subjects to build `teacher_subjects: [{subjects:{name}}]`
    t_ids = [r["id"] for r in t]
    ts = sb.table("teacher_subjects").select("teacher_id,subject_id").in_("teacher_id", t_ids or [-1]).execute().data or []
    subj_ids = list({x["subject_id"] for x in ts}) if ts else []
    subj_map: Dict[int, str] = {}
    if subj_ids:
        s = sb.table("subjects").select("id,name").in_("id", subj_ids).execute().data or []
        subj_map = {r["id"]: r["name"] for r in s}
    out = []
    for r in t:
        subjects_for = [x for x in ts if x["teacher_id"] == r["id"]]
        teacher_subjects = [{"subjects": {"name": subj_map.get(x["subject_id"], "")}} for x in subjects_for]
        r["teacher_subjects"] = teacher_subjects
        out.append(r)
    return {"teachers": out}

@app.delete("/delete-teacher/{teacher_id}")
def delete_teacher(teacher_id: int):
    sb.table("teacher_subjects").delete().eq("teacher_id", teacher_id).execute()
    sb.table("teachers").delete().eq("id", teacher_id).execute()
    return {"success": True, "message": "Teacher deleted successfully"}

@app.get("/get-parents")
def get_parents():
    prs = sb.table("parents").select("id,name,email,phone").order("id").execute().data or []
    p_ids = [p["id"] for p in prs]
    links = sb.table("parent_child").select("parent_id,student_id").in_("parent_id", p_ids or [-1]).execute().data or []
    s_ids = [x["student_id"] for x in links]
    studs = sb.table("students").select("id,name").in_("id", s_ids or [-1]).execute().data or []
    smap = {s["id"]: s["name"] for s in studs}
    children_map: Dict[int, List[Dict[str, Any]]] = {}
    for l in links:
        children_map.setdefault(l["parent_id"], []).append({"name": smap.get(l["student_id"], "—")})
    for p in prs:
        p["children"] = children_map.get(p["id"], [])
    return {"parents": prs}

@app.delete("/delete-parent/{parent_id}")
def delete_parent(parent_id: int):
    sb.table("parent_child").delete().eq("parent_id", parent_id).execute()
    sb.table("parents").delete().eq("id", parent_id).execute()
    return {"success": True, "message": "Parent deleted successfully"}

@app.get("/parents/{parent_id}/students")
def parent_students(parent_id: int):
    links = sb.table("parent_child").select("student_id").eq("parent_id", parent_id).execute().data or []
    s_ids = [x["student_id"] for x in links]
    if not s_ids: return {"success": True, "students": []}
    studs = sb.table("students").select("id,name,reg_no,grade").in_("id", s_ids).execute().data or []
    return {"success": True, "students": studs}

# ─────────── Announcements ───────────
@app.post("/add-announcement")
def add_announcement(body: AnnouncementIn):
    sb.table("announcements").insert({
        "message": body.message,
        "posted_by": body.posted_by or "Admin",
        "created_at": datetime.utcnow().isoformat()
    }).execute()
    return {"success": True, "message": "Announcement posted."}

@app.get("/get-announcements")
def get_announcements():
    res = sb.table("announcements").select("*").order("created_at", desc=True).execute()
    return {"success": True, "announcements": res.data or []}

# ─────────── Results & Performance ───────────
@app.get("/students/{student_id}/performance")
def student_performance(student_id: int):
    r = sb.table("results").select("subject_id,marks,created_at").eq("student_id", student_id).order("created_at", desc=True).execute().data or []
    if not r: return {"success": True, "performance": []}
    subj_ids = list({x["subject_id"] for x in r})
    subj = sb.table("subjects").select("id,name").in_("id", subj_ids or [-1]).execute().data or []
    subj_map = {s["id"]: s["name"] for s in subj}
    perf = [{"subject": subj_map.get(x["subject_id"], "—"), "marks": float(x["marks"])} for x in r]
    return {"success": True, "performance": perf}

@app.get("/admin/view-results")
def admin_view_results():
    res = sb.table("results").select("*").order("created_at", desc=True).limit(200).execute().data or []
    if not res: return {"success": True, "results": []}
    s_ids = list({x["student_id"] for x in res})
    sub_ids = list({x["subject_id"] for x in res})
    t_ids = list({x["teacher_id"] for x in res if x.get("teacher_id")})
    students = sb.table("students").select("id,reg_no,name,grade").in_("id", s_ids or [-1]).execute().data or []
    subs = sb.table("subjects").select("id,name").in_("id", sub_ids or [-1]).execute().data or []
    tusers = sb.table("users").select("id,name").in_("id", t_ids or [-1]).execute().data or []
    smap = {x["id"]: x for x in students}
    subjmap = {x["id"]: x["name"] for x in subs}
    tmap = {x["id"]: x["name"] for x in tusers}
    out = []
    for r in res:
        s = smap.get(r["student_id"], {})
        out.append({
            "student_reg": s.get("reg_no", "—"),
            "student_name": s.get("name", "—"),
            "grade": s.get("grade", "—"),
            "subject": subjmap.get(r.get("subject_id"), "—"),
            "teacher": tmap.get(r.get("teacher_id"), "—"),
            "marks": float(r.get("marks")),
            "term": r.get("term", "—"),
            "exam_type": r.get("exam_type", "Exam"),
        })
    return {"success": True, "results": out}

@app.get("/admin/results-summary")
def admin_results_summary(term: Optional[str] = None):
    # subjects per grade from subjects_by_grade
    sbg = sb.table("subjects_by_grade").select("grade,subject_id").execute().data or []
    subjects_by_grade: Dict[str, set] = {}
    for r in sbg:
        subjects_by_grade.setdefault(r["grade"], set()).add(r["subject_id"])

    students = sb.table("students").select("id,grade").execute().data or []
    if not students: return {"success": True, "summary": []}
    st_by_grade: Dict[str, List[int]] = {}
    for s in students:
        st_by_grade.setdefault(s["grade"], []).append(s["id"])

    # results filtered by term if provided
    res = sb.table("results").select("student_id,subject_id,term").execute().data or []
    if term:
        res = [x for x in res if x.get("term") == term]

    from collections import defaultdict
    uploaded_by_grade: Dict[str, set] = defaultdict(set)
    st_grade_map = {sid: g for g, lst in st_by_grade.items() for sid in lst}
    for r in res:
        g = st_grade_map.get(r["student_id"])
        if not g: continue
        uploaded_by_grade[g].add(r["subject_id"])

    summary = []
    for g, subs in subjects_by_grade.items():
        total = len(subs)
        uploaded = len(uploaded_by_grade.get(g, set()) & subs) if total > 0 else 0
        pending = max(0, total - uploaded)
        status = "Complete" if total and pending == 0 else ("In Progress" if uploaded else "Not Started")
        summary.append({"class": g, "total_subjects": total, "uploaded": uploaded, "pending": pending, "status": status})

    # include grades with students but no sbg mapping
    for g in sorted(set(st_by_grade.keys()) - set(subjects_by_grade.keys())):
        summary.append({"class": g, "total_subjects": 0, "uploaded": 0, "pending": 0, "status": "Not Started"})

    summary.sort(key=lambda x: x["class"])
    return {"success": True, "summary": summary}

@app.get("/admin/class-results/{grade}")
def admin_class_results(grade: str):
    studs = sb.table("students").select("id").eq("grade", grade).execute().data or []
    if not studs: return {"success": True, "subjects": []}
    s_ids = [x["id"] for x in studs]

    # subjects configured for this grade
    sbg = sb.table("subjects_by_grade").select("subject_id").eq("grade", grade).execute().data or []
    sub_ids = [x["subject_id"] for x in sbg]
    subs = sb.table("subjects").select("id,name").in_("id", sub_ids or [-1]).execute().data or []
    subjmap = {x["id"]: x["name"] for x in subs}

    # fetch results for students in this grade
    res = sb.table("results").select("subject_id,teacher_id,marks,student_id").in_("student_id", s_ids).execute().data or []

    from statistics import mean
    agg: Dict[int, Dict[str, Any]] = {sid: {"subject": subjmap.get(sid, "—"), "teacher": "—", "uploaded": 0, "pending": 0, "marks": []} for sid in sub_ids}
    for r in res:
        sid = r["subject_id"]
        if sid not in agg:  # in case of subjects outside mapping
            agg[sid] = {"subject": subjmap.get(sid, "—"), "teacher": "—", "uploaded": 0, "pending": 0, "marks": []}
        agg[sid]["uploaded"] += 1
        if r.get("marks") is not None:
            try:
                agg[sid]["marks"].append(float(r["marks"]))
            except Exception:
                pass

    # teacher names (from users since results.teacher_id -> users.id)
    t_ids = list({r["teacher_id"] for r in res if r.get("teacher_id")})
    tusers = sb.table("users").select("id,name").in_("id", t_ids or [-1]).execute().data or []
    tmap = {x["id"]: x["name"] for x in tusers}

    out = []
    total_students = len(s_ids)
    for sid, v in agg.items():
        avg = round(mean(v["marks"]), 2) if v["marks"] else None
        pending = max(0, total_students - v["uploaded"])
        # pick the most common teacher name for the subject (best-effort)
        if not v["teacher"] and t_ids:
            v["teacher"] = tmap.get(t_ids[0], "—")
        out.append({
            "subject": v["subject"], "teacher": v["teacher"],
            "uploaded": v["uploaded"], "pending": pending, "average_marks": avg
        })
    out.sort(key=lambda x: x["subject"])
    return {"success": True, "subjects": out}

# ─────────── Summarize (local) ───────────
@app.post("/summarize")
def summarize(body: SummarizeIn):
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Summarize the following text in clear, simple English."},
                {"role": "user", "content": body.text},
            ],
            temperature=0.2,
            max_tokens=150,
        )
        summary = response.choices[0].message.content.strip()
        return {"summary": summary}
    except Exception as e:
        print(f"[summarize] error: {e}")
        return {"summary": "⚠️ Unable to summarize at the moment."}
# ===============================
# AI Tutor (Explain Concepts)
# ===============================
@app.post("/explain")
def explain_concept(body: dict):
    """Explains a given concept using GPT"""
    concept = body.get("concept", "").strip()
    if not concept:
        return {"explanation": "Please provide a concept to explain."}

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a knowledgeable and friendly tutor. "
                        "Explain topics clearly, step-by-step, and in easy language suitable for parents and students."
                    ),
                },
                {"role": "user", "content": f"Explain this concept in detail: {concept}"},
            ],
            max_tokens=300,
        )

        explanation = response.choices[0].message.content.strip()
        return {"explanation": explanation}
    except Exception as e:
        print("[/explain] Error:", e)
        return {"explanation": "⚠️ Unable to explain this concept at the moment."}


# ===============================
# AI Question Generator
# ===============================
@app.post("/generate-questions")
def generate_questions(body: dict):
    """Generates 5 relevant exam-style questions from a passage or topic."""
    text = body.get("text", "").strip()
    if not text:
        return {"questions": "Please provide a passage or topic first."}

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a professional exam question generator. "
                        "Create thoughtful, varied, exam-style questions based on a given topic or passage."
                    ),
                },
                {"role": "user", "content": f"Generate 5 exam-style questions from this passage or topic:\n\n{text}"},
            ],
            max_tokens=300,
        )

        questions = response.choices[0].message.content.strip()
        return {"questions": questions}
    except Exception as e:
        print("[/generate-questions] Error:", e)
        return {"questions": "⚠️ Could not generate questions right now."}

# ─────────── Root ───────────
@app.get("/")
def root():
    return {"app": "BrightPath", "version": "1.0.0"}
